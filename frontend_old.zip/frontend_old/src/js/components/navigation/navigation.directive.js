/**
 * Created by svfat on 4/13/16.
 */
(function () {

    angular.module('putonghua')
        .directive('navigation', function () {
            return {
                templateUrl: '/static/templates/navigation/navigation.template.html',
            };
        });


})();