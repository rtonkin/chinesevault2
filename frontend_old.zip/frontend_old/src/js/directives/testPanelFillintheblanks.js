angular.module('putonghua')
    .directive('testPanelFillintheblanks', function() {
      return {
        restrict: 'E',
        templateUrl: '/static/templates/practiceWords/testPanelFillintheblanks.html'
      };
    });
