angular.module('putonghua')
    .directive('testPanelTonepracticewithaudio', function() {
      return {
        restrict: 'E',
        templateUrl: '/static/templates/practiceWords/testPanelTonepracticewithaudio.html'
      };
    });