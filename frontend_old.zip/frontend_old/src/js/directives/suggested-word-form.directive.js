angular.module('putonghua')
    .directive('suggestedWordForm', function($http, api) {
      return {
      	restrict: 'E',
        template:   
                  '<div class="col-md-12 text-center" ng-hide="!isFormSubmitted">' +
                    '<p style="font-weight:bold;margin:20px 15px;">Thank you for your valued input. Your suggestions will be considered for inclusion in the database.</p>' +
                    '<div class="form-group">'+
                      '<div class="col-xs-offset-3 col-xs-6 col-sm-6 col-sm-offset-3">'+
                          '<a ui-sref="dictionary" class="btn btn-md btn-block">Continue</a>'+
                      '</div>'+
                    '</div>'+
                  '</div>' +
                  '<div class="col-md-12 text-center">' +
                     ' <p style="font-weight:bold;margin:20px 15px;"  ng-hide="isFormSubmitted">Please enter the Chinese, pinyin (if known) and English. Your submission will be considered for inclusion in the dictionary. Thank you!</p>' +
                  '</div>' +
                  '<div class="col-sm-8 col-sm-offset-2"  ng-hide="isFormSubmitted">' +
                    '<form class="form-horizontal" ng-submit="submit()" name="wordsForm" novalidate>'+
	      							'<fieldset ng-repeat="form in wordsForm">' +
										  	'<div class="form-group">' +
										    	'<label for="chinese" class="col-sm-2 control-label">Chinese</label>' +
										    	'<div class="col-sm-10">' +
										      		'<input type="text" class="form-control" id="chinese" placeholder="Enter chinese" ng-model="form.chinese" required>' +
										    	'</div>' +
										  	'</div>' +
										  	'<div class="form-group">' +
										    	'<label for="pinyin" class="col-sm-2 control-label">Pinyin</label>' +
									    		'<div class="col-sm-10">' +
									      			'<input type="text" class="form-control" id="pinyin" ng-model="form.pinyin" placeholder="Enter pinyin">' +
										    	'</div>' +
										  	'</div>' +
										  	'<div class="form-group">' +
										    	'<label for="english" class="col-sm-2 control-label">English</label>' +
									    		'<div class="col-sm-10">' +
									      			'<input type="text" class="form-control" id="english" ng-model="form.english" placeholder="Enter english" required>' +
										    	'</div>' +
										  	'</div>' +
				            				'<hr>' +
	            				'</fieldset>'+
	            				'<div class="form-group">'+
									    	'<div class="col-xs-offset-3 col-xs-6 col-sm-6 col-sm-offset-3 text-center">'+
                            '<a href="#" class="btn-add-word" ng-click="addForm(form)" ng-hide="wordsForm.length > 4">+ Add Another Word</a><br/>'+
									    			'<a href="#" class="btn-add-word" ng-click="deleteForm(form)" ng-show="wordsForm.length > 1"> Delete Last Word</a>'+
									      		'<button type="submit" class="btn btn-md btn-block">Submit</button>'+
									    	'</div>'+
									  	'</div>'+
									  '</form>'+
                  '</div>',
									  	
    	link: function($scope, element, attrs) {
    		var wordsForm = $scope.wordsForm = [];
        $scope.isFormSubmitted = false;
    		{ wordsForm.push({ /* don't need anything here */ }); };
        if(wordsForm.length >= 4) {
        }
    		$scope.addForm = function() {
    			if(wordsForm.length < 5) {
    				{ wordsForm.push({ /* don't need anything here */ }); };
    			} if(wordsForm.length > 4) {
            $scope.canAddFields = false;
          }
    		}

        $scope.deleteForm = function() {
          wordsForm.length = wordsForm.length - 1;
        }

    		$scope.submit = function () {
          $scope.isFormSubmitted = true;
  				for(var i = 0; i < wordsForm.length; i++) {
            api.addWords(wordsForm[i].chinese, wordsForm[i].english, wordsForm[i].pinyin);
          }
        };
    	}
    };
  });