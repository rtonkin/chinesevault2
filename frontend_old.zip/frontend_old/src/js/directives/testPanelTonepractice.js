angular.module('putonghua')
    .directive('testPanelTonepractice', function() {
      return {
        restrict: 'E',
        templateUrl: '/static/templates/practiceWords/testPanelTonepractice.html'
      };
    });
