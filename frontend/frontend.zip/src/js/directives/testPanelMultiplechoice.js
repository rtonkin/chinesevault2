angular.module('putonghua')
    .directive('testPanelMultiplechoice', function() {
      return {
        restrict: 'E',
        templateUrl: '/static/templates/practiceWords/testPanelMultiplechoice.html'
      };
    });
